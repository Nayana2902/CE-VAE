from src.modules.capsules.primary import PrimaryCaps
from src.modules.capsules.digit import DigitCaps

__ALL__ = [
    PrimaryCaps,
    DigitCaps
]